/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicafinalsmm;

import java.awt.image.BufferedImage;

/**
 *
 * @author mati
 */
public class VentanaInternaSM {

    public VentanaInternaSM() {
    }
    
    public BufferedImage getImage(){
        return null;
    }
    
    public BufferedImage getShort(){ // instantanea
        return null;
    }
    
    public BufferedImage getCam(){ // instantanea
        return null;
    }
    
}
